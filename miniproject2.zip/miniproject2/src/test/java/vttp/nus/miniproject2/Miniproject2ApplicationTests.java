package vttp.nus.miniproject2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Miniproject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
